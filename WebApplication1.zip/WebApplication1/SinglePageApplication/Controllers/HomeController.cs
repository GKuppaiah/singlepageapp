﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SinglePageApplication.Models;
using System.Diagnostics;

namespace SinglePageApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

       

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
         }

        public async Task<IActionResult> Index()
        {

            GroupList();
            return View();
        }
        private async Task<IActionResult> GroupList()
        {
            var client = new HttpClient();
            List<GroupList> groupList = new List<GroupList>();
            var response = client.GetAsync("https://localhost:7208/GetGroupsCount").Result;
            string jsonString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            groupList.AddRange(JsonConvert.DeserializeObject<List<GroupList>>(jsonString).ToList());
            ViewBag.GroupList = groupList;
            return (IActionResult)groupList;
        }

        [HttpPost]
        public IActionResult Index(string id)
        {
            string txtVal = Request.Form["textbox"][0];
            BindRequestInfo(txtVal);
            GroupList();
            return View();
        }
        public async Task<RequestInfo> BindRequestInfo(string id)
        {
            var requestInfo = new RequestInfo();
            if (!string.IsNullOrEmpty(id))
            {
                var client = new HttpClient();
                var response = client.GetAsync(string.Format("{0}/{1}", "https://localhost:7208/GetRequestInfo", id)).Result;
                string jsonString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var result = JsonConvert.DeserializeObject<RequestInfo>(jsonString);
                var reqInfo = new RequestInfo
                {
                    Duration = result.Duration,
                    RequestMessage = result.RequestMessage,
                    RequstTime = result.RequstTime,
                    ResponseMessage = result.ResponseMessage,
                    ResponseTime = result.ResponseTime
                };
                ViewBag.RequestInfo = reqInfo;
                requestInfo = reqInfo;
            }
            return requestInfo;
        }


    }
}