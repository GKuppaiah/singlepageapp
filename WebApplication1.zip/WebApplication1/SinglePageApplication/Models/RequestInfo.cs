﻿namespace SinglePageApplication.Models
{
    public class RequestInfo
    {
        public DateTime RequstTime { get; set; }

        public DateTime ResponseTime { get; set; }

        public int Duration { get; set; }

        public string? RequestMessage { get; set; }

        public string? ResponseMessage { get; set; }
    }
}
