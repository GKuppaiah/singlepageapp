﻿namespace WebApplication1.Models
{
    public class GroupList
    {
        public string? Name { get; set; }

        public int? Count { get; set; } = 0;
    }
}
