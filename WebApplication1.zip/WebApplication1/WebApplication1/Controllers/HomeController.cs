﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HomeController : Controller
    {
        protected string? folderPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)!.Split("\\bin")!.FirstOrDefault() ?? "";
        protected string[] fileList = { "WebApi_DataAccessLog_01.log", "WebApi_DataAccessLog_02.log" };

        [HttpGet]
        [Route("/GetGroupsCount")]
        [Produces("application/json")]
        public IActionResult GetGroupsCount()
        {
            return Ok(getGroupdCount());
        }

        [HttpGet]
        [Route("/GetRequestInfo/{id}")]
        [Produces("application/json")]
        public IActionResult GetRequestInfo(string id)
        {
            var requestInfo = getRequestById(id);
            if (requestInfo != null)
                return Ok(requestInfo);
            else
                return NotFound();
        }

        private List<GroupList> getGroupdCount()
        {
            var groups = new List<GroupList>();
           
            foreach (var file in fileList)
            {
                string path = Path.Combine(folderPath!, $"Data\\{file}");
                MatchCollection matches = Regex.Matches(Convert.ToString(System.IO.File.ReadAllText(path)), @"(?:\""ApiId\"":\"")(.*?)(?:\"")");
                var result = (from match in matches
                              group match by match?.Value into g
                              select new GroupList() { Name = Regex.Match(g.Key, @"(?<=ApiId\"":\"")\w+")?.Value!, Count = g.Count() }).ToList();
                
                groups.AddRange(result);
            }
            return (from finalGroup in groups
                    group finalGroup by finalGroup.Name into g
                    select new GroupList() { Name = g.Key, Count = g.Sum(x =>x.Count ?? 0) }).ToList();
        }

        private RequestInfo getRequestById(string? id)
        {
            var response = new RequestInfo();
            foreach (var file in fileList)
            {
                string path = Path.Combine(folderPath!, $"Data\\{file}");
                var request = (from line in System.IO.File.ReadAllLines(path)
                               where Regex.IsMatch(line, $@"(?:\""ID\"":\"")({id})(?:\"")") == true && 
                               (Regex.IsMatch(line, $@"(?:\""INFORMATION_TYPE\"":\"")(REQUEST)(?:\"")") == true
                               || Regex.IsMatch(line, $@"(?:\""INFORMATION_TYPE\"":\"")(RESPONSE)(?:\"")") == true)
                               select line).ToList();

                
                response.RequstTime = Convert.ToDateTime(request.Where(x => Regex.IsMatch(x, $@"(?:\""INFORMATION_TYPE\"":\"")(REQUEST)(?:\"")") == true)?.FirstOrDefault()?.Substring(0,23));
                response.ResponseTime = Convert.ToDateTime(request.Where(x => Regex.IsMatch(x, $@"(?:\""INFORMATION_TYPE\"":\"")(RESPONSE)(?:\"")") == true)?.FirstOrDefault()?.Substring(0, 23));
                TimeSpan duration = response.ResponseTime - response.RequstTime;
                response.Duration = duration.Milliseconds;
                var requestString = request.Where(x => Regex.IsMatch(x, $@"(?:\""INFORMATION_TYPE\"":\"")(REQUEST)(?:\"")") == true).FirstOrDefault()?? "";
                var requestMatch = JObject.Parse(requestString.Substring(24).Replace("\b", ""));
                response.RequestMessage = requestMatch["RawRequest"]?.Parent?.ToString();
                var responseString = request.Where(x => Regex.IsMatch(x, $@"(?:\""INFORMATION_TYPE\"":\"")(RESPONSE)(?:\"")") == true).FirstOrDefault() ?? "";
                var responseMatch = JObject.Parse(responseString.Substring(24).Replace("\b", ""));
                response.ResponseMessage = responseMatch["Response"]?.Parent?.ToString();

                return response;
            }
            return response;
        }
    }

    
}
